package com.fabricadescripts;

public class HexadecimalAdapter extends Calculadora {

    public void Dec2Hex(Integer res) {
        System.out.println("Hexadecimal: " + Integer.toString(res, 16));
    }


}
