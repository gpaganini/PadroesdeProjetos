package com.fabricadescripts;

public class BinaryAdapter extends Calculadora {

    public void Dec2Bin(Integer res) {
        System.out.println("Binário: " + Integer.toString(res, 2));
    }
}
