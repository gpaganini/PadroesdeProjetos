package com.fabricadescripts;

public class OctalAdapter extends Calculadora {

    public void Dec2Octa(Integer res) {
        System.out.println("Octal: " + Integer.toString(res, 8));
    }
}
